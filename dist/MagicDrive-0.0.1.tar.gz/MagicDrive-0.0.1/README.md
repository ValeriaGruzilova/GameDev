# ![Game Icon](https://github.com/Valery-Gruzilova/GameDev/blob/master/src/background/icon.jpg) MagicDrive

## Краткое описание проекта:
Авторская однопользовательская игра в жанре аркада на ПК, написанная на Python 3.9 с использованием библиотеки PyGame.
## Авторы:
GameDevelopment (game designer, coder & tester) — Валерия Грузилова  
Artist — Дарина Федер
